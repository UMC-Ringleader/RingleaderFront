package com.example.ringleaderfront

import java.io.Serializable

data class tag(var tagText:String):Serializable
