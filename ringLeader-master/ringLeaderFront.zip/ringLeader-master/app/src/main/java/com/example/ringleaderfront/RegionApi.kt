package com.example.ringleaderfront

interface RegionApi {
}