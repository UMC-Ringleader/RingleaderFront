package com.example.ringleaderfront

interface FeedbackApi {
}