package com.example.ringleaderfront

class RankingApi {
}