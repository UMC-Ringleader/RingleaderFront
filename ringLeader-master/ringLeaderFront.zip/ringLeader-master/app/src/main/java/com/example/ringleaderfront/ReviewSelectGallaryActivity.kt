package com.example.ringleaderfront

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ReviewSelectGallaryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_review_select_gallary)
    }
}